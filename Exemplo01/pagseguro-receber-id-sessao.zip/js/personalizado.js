function pagamento(){
    var endereco = jQuery('.endereco').attr("data-endereco");
    $.ajax({
        url: endereco + "pagamento.php",
        type: 'POST',
        dataType: 'json',
        success: function (retorno) {
            //console.log(retorno);
            PagSeguroDirectPayment.setSessionId(retorno.id);
        }
    });
}


